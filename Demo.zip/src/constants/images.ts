// 404 error image
import ErrorImg from "@/assets/images/png/error-img.png";
import RightWire from "@/assets/images/png/rightWire.png";
import LeftWire from "@/assets/images/png/leftWire.png";
import Sarvidhi from "@/assets/images/svg/Sarvidhi.svg";
import BrokerDetail from "@/assets/images/svg/BrokerDetail.svg";
import Dollar from "@/assets/images/svg/Dollar.svg"
import File from "@/assets/images/svg/File.svg"
import Line from "@/assets/images/svg/Line.svg"
import ComingSoon from "@/assets/images/png/ComingSoon.jpg"


export { ErrorImg, LeftWire, RightWire,Sarvidhi ,BrokerDetail,Dollar,File,Line,ComingSoon};
