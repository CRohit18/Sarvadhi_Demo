export const EmailRequired = "Please enter email address.";
export const EmailValidation = "Please enter valid email address.";
export const PasswordRequired = "Please enter password.";
export const PasswordValidation = "Password must be at least 6 characters.";
export const somethingWentWrong =
  "Something went wrong,please try again later.";
 export const brokerUpdated =  "Broker updated successfully..."
 export const brokerAdded =  "Broker Added successfully..."
 export const brokerDeleted = "Broker deleted successfully..."
 export const brokerStatusChanged = "Broker status changed successfully..."


 


 

 