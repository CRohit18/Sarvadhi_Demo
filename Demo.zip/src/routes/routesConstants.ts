const routesConstants = {
  LOGIN: "/login",
  FORGOT_PASSWORD: "/forgot-password",
  UNAUTHORIZED: "/unauthorized",
  _404: "*",
  BROKER:"/brokerDeatils",
  DIAMOND:"/diamondDetails",
  TRANSACTION:"/transaction"
};
export default routesConstants;
