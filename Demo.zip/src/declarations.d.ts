declare module "*.gif" {
  const src: string;
  export default src;
}
